package timeTableGeneration;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import actions.chats.Query;
import settings.database.PostgreSQLConnection;

/**
 * Servlet implementation class SaveTimeTable
 */
public class SaveTimeTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveTimeTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			PreparedStatement proc = PostgreSQLConnection.getConnection().prepareStatement("SELECT public.\"setSavedTimetable\"(?,?,?,?,?,?,?,?);");
			
			System.out.println(request.getParameter("json_list").toString());
			JSONArray jsonArray = new JSONArray(request.getParameter("json_list"));
			
			for(int i =0 ;i<jsonArray.length();i++){
				JSONObject obj = jsonArray.getJSONObject(i);
				proc.setInt(1,Integer.valueOf(obj.get("dept").toString()));
			
				proc.setInt(2,Integer.valueOf(obj.get("sem").toString()));
				proc.setInt(3,Integer.valueOf(obj.get("batch").toString()));

				proc.setInt(4,Integer.valueOf(obj.get("time_slot").toString()));
				proc.setString(5,obj.get("day").toString());
				proc.setString(6,obj.get("subject_name").toString());
				
				
				proc.setString(7,obj.get("faculty_name").toString());
				proc.setString(8,obj.get("venue_name").toString());
				proc.execute();
						
			}
			
			proc.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//query
		
			
		
	}



}
